<footer class="py-3  bg-dark text-white">
  <div class="container">
    <div class="row">
      
      <!-- Columna de derechos de autor -->
      <div class="col-lg-4 col-md-4 col-sm-12">
        <p>@ Copyright 2023 Golem J. Fer Salazar</p>
      </div>
      
    </div>
  </div>
</footer>