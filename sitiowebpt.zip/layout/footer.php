
 <footer class="py-3  bg-dark text-white">
  <div class="container">
    <div class="row">
      <!-- Columna de información -->
      <div class="col-lg-4 col-md-4 col-sm-12">
      <p>Dirección:</p>
        <p>Rinconada precolombina #02<br>
          Pedregal de carrasco<br>
          Coyoacan. 04700 CDMX</p>
      </div>
      <!-- Columna de derechos de autor -->
      <div class="col-lg-4 col-md-4 col-sm-12">
        <p>@ Copyright 2023 Golem J. Fer Salazar</p>
      </div>
      <!-- Columna de información de contacto -->
      <div class="col-lg-4 col-md-4 col-sm-12">
        <p>  <img src="assets/images/envelope.png" alt="facebook style="width: 16px; height: 16px;">&nbsp golemseg@gmail.com </p>
          <a href="https://www.facebook.com/golemseg/" class="active" ">
            <img src="assets/images/facebook.png" alt="facebook style="width: 16px; height: 16px;">
          </a>
      </div>
    </div>
  </div>
</footer>