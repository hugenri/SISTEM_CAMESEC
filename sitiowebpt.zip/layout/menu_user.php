<nav>
<div class="custom-topnav" id="myTopnav">
<a href="#home" class="active" style="display: flex; align-items: center;">
    <img src="assets/images/home.png" alt="Home" style="width: 16px; height: 16px;">
  </a>
  <div class="custom-dropdown">
    <button class="dropbtn">Productos 
      <i></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 
  <div class="custom-dropdown">
    <button class="dropbtn">Servicios 
      <i></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 

  <div class="custom-dropdown">
    <button class="dropbtn">Conceptos de facturación 
      <i></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 

  <div class="custom-dropdown">
    <button class="dropbtn">Cotizaciones 
      <i></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 
  <a href="clases/cerrar_sesion.php">Salir</a>
  <a href="javascript:void(0);" style="font-size:19px; margin-right: 10px;" class="icon" onclick="responsive_topnav()">&#9776;</a>

</div>

</nav>

